var database = require("../database/config");

function salvarQuestionario(tempExpMeses, maxDistancia, freqSemanal , objetivo, fkUsuario){
    var instrucaoSql = `
        INSERT INTO questionario (tempExpMeses, maxDistancia, freqSemanal, objetivo, fkUsuario) VALUES
            (${tempExpMeses}, ${maxDistancia}, ${freqSemanal}, ${objetivo}, ${fkUsuario});
    `

    console.log("Executando a instrução SQL: \n" + instrucaoSql);
    return database.executar(instrucaoSql);

}

    module.exports = {
        salvarQuestionario
    }